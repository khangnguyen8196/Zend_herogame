<?php

/**
 *
 */
class UtilCategory {
    
}
